// GTA VI - joke firmware for M5Stack Cardputer ADV
// Boot animation + first-run setup wizard + fake "game".
// NOTE: boot animation and setup steps are placeholders until matched to the original.

#include <M5Cardputer.h>
#include <Preferences.h>
#include <WiFi.h>

static const int W = 240;
static const int H = 135;

Preferences prefs;
M5Canvas cv(&M5Cardputer.Display);

// ---------- settings ----------
struct Settings {
  String player = "Player";
  String ssid = "";
  String pass = "";
  int brightness = 160;  // 10..255
  int volume = 120;      // 0..255
} cfg;

void loadSettings() {
  prefs.begin("gta6", true);
  cfg.player = prefs.getString("player", "Player");
  cfg.ssid = prefs.getString("ssid", "");
  cfg.pass = prefs.getString("pass", "");
  cfg.brightness = prefs.getInt("bright", 160);
  cfg.volume = prefs.getInt("vol", 120);
  prefs.end();
}

void saveSettings() {
  prefs.begin("gta6", false);
  prefs.putString("player", cfg.player);
  prefs.putString("ssid", cfg.ssid);
  prefs.putString("pass", cfg.pass);
  prefs.putInt("bright", cfg.brightness);
  prefs.putInt("vol", cfg.volume);
  prefs.putBool("setup", true);
  prefs.end();
}

bool setupDone() {
  prefs.begin("gta6", true);
  bool v = prefs.getBool("setup", false);
  prefs.end();
  return v;
}

void applyHw() {
  M5Cardputer.Display.setBrightness(cfg.brightness);
  M5Cardputer.Speaker.setVolume(cfg.volume);
}

// ---------- helpers ----------
uint16_t col(uint8_t r, uint8_t g, uint8_t b) { return M5Cardputer.Display.color565(r, g, b); }

void mix(uint8_t r1, uint8_t g1, uint8_t b1, uint8_t r2, uint8_t g2, uint8_t b2, float t,
         uint8_t &r, uint8_t &g, uint8_t &b) {
  r = r1 + (r2 - r1) * t;
  g = g1 + (g2 - g1) * t;
  b = b1 + (b2 - b1) * t;
}

// sunset gradient: deep purple (top) -> hot pink -> orange (bottom)
void sunset(float v, uint8_t &r, uint8_t &g, uint8_t &b) {
  if (v < 0.5f) mix(50, 10, 90, 250, 60, 150, v * 2.0f, r, g, b);
  else mix(250, 60, 150, 255, 150, 50, (v - 0.5f) * 2.0f, r, g, b);
}

void drawSky(float k) {
  for (int y = 0; y < H; y++) {
    uint8_t r, g, b;
    sunset((float)y / H, r, g, b);
    cv.drawFastHLine(0, y, W, col(r * k, g * k, b * k));
  }
}

// gradient-filled text drawn in horizontal strips
void gradText(const char *s, int cx, int cy, int size, float k) {
  cv.setTextSize(size);
  cv.setTextDatum(middle_center);
  int h = 8 * size;
  int top = cy - h / 2;
  for (int y = top; y < top + h; y += 2) {
    float v = (float)(y - top) / h;
    uint8_t r, g, b;
    mix(255, 240, 200, 255, 120, 190, v, r, g, b);
    cv.setClipRect(0, y, W, 2);
    cv.setTextColor(col(r * k, g * k, b * k));
    cv.drawString(s, cx, cy);
  }
  cv.clearClipRect();
}

struct Key {
  char c = 0;
  bool enter = false, del = false, esc = false;
};

bool pollKey(Key &k) {
  M5Cardputer.update();
  if (M5Cardputer.Keyboard.isChange() && M5Cardputer.Keyboard.isPressed()) {
    auto st = M5Cardputer.Keyboard.keysState();
    k = Key();
    k.enter = st.enter;
    k.del = st.del;
    for (char c : st.word) {
      if (c == '`') k.esc = true;
      else k.c = c;
    }
    return k.enter || k.del || k.esc || k.c;
  }
  return false;
}

void header(const char *title, int step, int total) {
  cv.fillSprite(col(20, 8, 40));
  cv.fillRect(0, 0, W, 18, col(250, 60, 150));
  cv.setTextDatum(middle_left);
  cv.setTextSize(1);
  cv.setTextColor(TFT_WHITE);
  cv.drawString(title, 6, 9);
  if (total) {
    char buf[12];
    snprintf(buf, sizeof(buf), "%d/%d", step, total);
    cv.setTextDatum(middle_right);
    cv.drawString(buf, W - 6, 9);
  }
}

// ---------- boot animation ----------
void bootAnimation() {
  cv.createSprite(W, H);
  M5Cardputer.Display.setBrightness(cfg.brightness);

  // 1) fade-in sky + rising sun + logo
  const int frames = 50;
  for (int f = 0; f <= frames; f++) {
    float t = (float)f / frames;
    float e = 1.0f - (1.0f - t) * (1.0f - t);
    drawSky(e);
    int sunY = 150 - (int)(80 * e);
    cv.fillCircle(W / 2, sunY, 38, col(255 * e, 200 * e, 90 * e));
    for (int i = 0; i < 6; i++)  // sun stripes
      cv.fillRect(W / 2 - 40, sunY + 4 + i * 7, 80, 1 + i / 2, col(60 * e, 10 * e, 90 * e));
    gradText("GTA VI", W / 2, 50, 4, e);
    cv.pushSprite(0, 0);
    if (f == 8) M5Cardputer.Speaker.tone(440, 80);
    if (f == 20) M5Cardputer.Speaker.tone(660, 80);
    if (f == 32) M5Cardputer.Speaker.tone(880, 160);
    delay(22);
  }

  // 2) progress bar
  const int bx = 40, bw = 160, by = 112;
  for (int p = 0; p <= 99; p++) {
    drawSky(1.0f);
    cv.fillCircle(W / 2, 70, 38, col(255, 200, 90));
    gradText("GTA VI", W / 2, 50, 4, 1.0f);
    cv.drawRoundRect(bx, by, bw, 8, 4, TFT_WHITE);
    cv.fillRoundRect(bx + 2, by + 2, (bw - 4) * p / 100, 4, 2, TFT_WHITE);
    cv.setTextSize(1);
    cv.setTextDatum(top_center);
    cv.setTextColor(TFT_WHITE);
    char buf[24];
    snprintf(buf, sizeof(buf), "Loading... %d%%", p);
    cv.drawString(buf, W / 2, by + 12);
    cv.pushSprite(0, 0);
    delay(p < 70 ? 14 : (p < 90 ? 30 : 60));
  }

  // 3) joke: stuck at 99%
  const char *jokes[] = {"Loading... 99%", "Still 99%...", "Waiting for Trailer 3", "Almost there. Honest."};
  for (int j = 0; j < 4; j++) {
    cv.fillRect(0, by + 10, W, 14, col(255, 150, 50));
    cv.setTextDatum(top_center);
    cv.setTextColor(TFT_WHITE);
    cv.drawString(jokes[j], W / 2, by + 12);
    cv.pushSprite(0, 0);
    delay(700);
  }
  M5Cardputer.Speaker.tone(1046, 200);
}

// ---------- setup wizard widgets ----------
bool textInput(const char *title, int step, int total, String &out, bool hide, const char *hint) {
  String buf = out;
  while (true) {
    header(title, step, total);
    cv.setTextDatum(top_left);
    cv.setTextColor(TFT_WHITE);
    cv.drawString(hint, 8, 30);
    cv.drawRect(8, 55, W - 16, 22, TFT_WHITE);
    String shown = hide ? String(std::string(buf.length(), '*').c_str()) : buf;
    cv.setTextSize(2);
    cv.drawString(shown.length() > 16 ? shown.substring(shown.length() - 16) : shown, 12, 58);
    cv.setTextSize(1);
    cv.setTextColor(col(255, 150, 50));
    cv.drawString("ENTER ok   ` skip   DEL erase", 8, 118);
    cv.pushSprite(0, 0);
    Key k;
    while (!pollKey(k)) delay(10);
    if (k.enter) { out = buf; return true; }
    if (k.esc) return false;
    if (k.del && buf.length()) buf.remove(buf.length() - 1);
    else if (k.c && buf.length() < 32) buf += k.c;
  }
}

void sliderStep(const char *title, int step, int total, int &val, int lo, int hi, int stepSize, bool isBright) {
  while (true) {
    header(title, step, total);
    cv.drawRect(20, 60, W - 40, 16, TFT_WHITE);
    cv.fillRect(22, 62, (W - 44) * (val - lo) / (hi - lo), 12, col(255, 150, 50));
    cv.setTextDatum(top_center);
    cv.setTextColor(TFT_WHITE);
    char b[16];
    snprintf(b, sizeof(b), "%d%%", (val - lo) * 100 / (hi - lo));
    cv.drawString(b, W / 2, 84);
    cv.drawString("LEFT , / RIGHT /    ENTER ok", W / 2, 118);
    cv.pushSprite(0, 0);
    Key k;
    while (!pollKey(k)) delay(10);
    if (k.enter) return;
    if (k.c == ',') val = max(lo, val - stepSize);
    if (k.c == '/') val = min(hi, val + stepSize);
    if (isBright) M5Cardputer.Display.setBrightness(val);
    else {
      M5Cardputer.Speaker.setVolume(val);
      M5Cardputer.Speaker.tone(800, 60);
    }
  }
}

void messageScreen(const char *title, const char *l1, const char *l2) {
  header(title, 0, 0);
  cv.setTextDatum(top_center);
  cv.setTextColor(TFT_WHITE);
  cv.drawString(l1, W / 2, 50);
  cv.drawString(l2, W / 2, 66);
  cv.setTextColor(col(255, 150, 50));
  cv.drawString("Press ENTER", W / 2, 112);
  cv.pushSprite(0, 0);
  Key k;
  while (true) {
    if (pollKey(k) && k.enter) return;
    delay(10);
  }
}

void connectWifi() {
  if (cfg.ssid.isEmpty()) return;
  header("Wi-Fi", 0, 0);
  cv.setTextDatum(middle_center);
  cv.setTextColor(TFT_WHITE);
  cv.drawString("Connecting...", W / 2, H / 2);
  cv.pushSprite(0, 0);
  WiFi.mode(WIFI_STA);
  WiFi.begin(cfg.ssid.c_str(), cfg.pass.c_str());
  uint32_t t0 = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - t0 < 8000) delay(100);
}

void setupWizard() {
  const int N = 5;
  messageScreen("Welcome", "Welcome to GTA VI", "Let's set things up");
  String name = cfg.player;
  if (textInput("Player name", 1, N, name, false, "What should we call you?")) cfg.player = name;

  String ssid = cfg.ssid, pass = cfg.pass;
  if (textInput("Wi-Fi network", 2, N, ssid, false, "Network name (` to skip)")) {
    cfg.ssid = ssid;
    if (textInput("Wi-Fi password", 3, N, pass, true, "Password")) cfg.pass = pass;
  }
  sliderStep("Brightness", 4, N, cfg.brightness, 10, 255, 15, true);
  sliderStep("Volume", 5, N, cfg.volume, 0, 255, 15, false);
  saveSettings();
  applyHw();
  connectWifi();
  messageScreen("All set", "Setup complete", "Have fun in Vice City");
}

// ---------- home screen ----------
void homeScreen() {
  int tick = 0;
  while (true) {
    drawSky(1.0f);
    cv.fillCircle(W / 2, 80, 30, col(255, 200, 90));
    gradText("GTA VI", W / 2, 30, 4, 1.0f);
    cv.setTextSize(1);
    cv.setTextDatum(top_center);
    cv.setTextColor(TFT_WHITE);
    String hello = "Hello, " + cfg.player;
    cv.drawString(hello, W / 2, 62);
    cv.drawString("Release date: soon(tm)", W / 2, 76);
    cv.drawString("ENTER = play    ` = re-run setup", W / 2, 118);
    cv.pushSprite(0, 0);

    Key k;
    if (pollKey(k)) {
      if (k.enter) {
        for (int p = 0; p <= 99; p++) {
          cv.fillSprite(TFT_BLACK);
          cv.setTextDatum(middle_center);
          cv.setTextColor(TFT_WHITE);
          char b[32];
          snprintf(b, sizeof(b), "Starting game... %d%%", p);
          cv.drawString(b, W / 2, H / 2);
          cv.pushSprite(0, 0);
          delay(20);
        }
        cv.fillSprite(TFT_BLACK);
        cv.drawString("Error: wait for GTA VI", W / 2, H / 2);
        cv.drawString("Try again later", W / 2, H / 2 + 14);
        cv.pushSprite(0, 0);
        M5Cardputer.Speaker.tone(220, 300);
        delay(2000);
      } else if (k.esc) {
        setupWizard();
      }
    }
    tick++;
    delay(20);
  }
}

void setup() {
  auto c = M5.config();
  M5Cardputer.begin(c, true);  // true = enable keyboard (works on ADV, TCA8418)
  M5Cardputer.Display.setRotation(1);
  M5Cardputer.Display.setTextFont(&fonts::Font0);
  cv.createSprite(W, H);
  loadSettings();
  applyHw();
  bootAnimation();
  if (!setupDone()) setupWizard();
  else connectWifi();
}

void loop() { homeScreen(); }
